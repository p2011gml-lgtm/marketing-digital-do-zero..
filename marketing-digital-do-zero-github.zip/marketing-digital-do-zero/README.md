# Marketing Digital do Zero

Site responsivo com página inicial, questionário de 10 perguntas, resultado orientativo e link para o checkout Kiwify.

## Como publicar no GitHub Pages
1. Crie um repositório público no GitHub.
2. Envie `index.html` para a raiz do repositório.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main`, pasta `/(root)`, e salve.

Checkout configurado: https://pay.kiwify.com.br/Nqq0JO3

Observação: a capa do guia é uma ilustração feita em CSS. Confira e atualize as informações do produto antes de divulgar.
